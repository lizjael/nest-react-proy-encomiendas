// backend/src/users/users.controller.ts
import {
  Controller,
  Get,
  Patch,
  Delete,
  Param,
  Body,
  ParseIntPipe,
} from '@nestjs/common';
import { UsersService } from './users.service';
import { Auth } from '../auth/decorators/auth.decorators';
import { ActiveUser } from '../common/decorators/active-user.decorator';
import { Role } from '../common/enums/rol.enum';
import type { UserActiveInterface } from '../common/interfaces/user-active.interface';
import { UpdateProfileDto } from './dto/update-profile.dto';

@Controller('users')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  // GET /users/me — perfil propio (cualquier rol autenticado)
  @Get('me')
  @Auth(Role.USER)
  getMe(@ActiveUser() user: UserActiveInterface) {
    return this.usersService.findOneByEmail(user.email);
  }

  // PATCH /users/me/perfil — actualizar perfil propio
  @Patch('me/perfil')
  @Auth(Role.USER)
  updateMe(
    @ActiveUser() user: UserActiveInterface,
    @Body() dto: UpdateProfileDto,
  ) {
    return this.usersService.updateProfile(user.sub, dto);
  }

  // GET /users — listar todos (admin y super_admin)
  @Get()
  @Auth(Role.ADMIN)
  findAll() {
    return this.usersService.findAll();
  }

  // GET /users/:id
  @Get(':id')
  @Auth(Role.ADMIN)
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.usersService.findOneById(id);
  }

  // PATCH /users/:id/perfil — admin edita empleado
  @Patch(':id/perfil')
  @Auth(Role.ADMIN)
  updateProfile(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateProfileDto,
  ) {
    return this.usersService.updateProfile(id, dto);
  }

  // DELETE /users/:id — solo super_admin
  @Delete(':id')
  @Auth(Role.SUPER_ADMIN)
  remove(@Param('id', ParseIntPipe) id: number) {
    return this.usersService.softDelete(id);
  }
}
