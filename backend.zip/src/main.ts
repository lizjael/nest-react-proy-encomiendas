// backend/src/main.ts — REEMPLAZA tu main.ts con esto
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { ValidationPipe } from '@nestjs/common';

async function bootstrap() {
  const app = NestFactory.create(AppModule);

  // ✅ CORS para el frontend Vite (puerto 5173)
  app.enableCors({
    origin: ['http://localhost:5173'],
    methods: ['GET', 'POST', 'PATCH', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    credentials: true,
  });

  // Validación global de DTOs
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true, // elimina campos no definidos en el DTO
      forbidNonWhitelisted: false,
      transform: true, // transforma tipos (string -> number con @Type)
    }),
  );

  await app.listen(3000);
  console.log('Backend corriendo en http://localhost:3000');
}
bootstrap();
